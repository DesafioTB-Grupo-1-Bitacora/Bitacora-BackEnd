module.exports = {
    authorizer: require("./authorizer"),
    fieldsValidator: require("./fieldsValidator")
}