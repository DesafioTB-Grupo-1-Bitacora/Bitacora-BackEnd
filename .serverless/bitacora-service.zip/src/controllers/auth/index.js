module.exports = {
    signin: require("./signin"),
    signup: require("./signup"),
    signout: require("./signout"),
    getUser: require("./getUser")
}